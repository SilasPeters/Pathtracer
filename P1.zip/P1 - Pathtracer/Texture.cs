﻿namespace EpicRaytracer
{
    public class Texture
    {
        
    }
}